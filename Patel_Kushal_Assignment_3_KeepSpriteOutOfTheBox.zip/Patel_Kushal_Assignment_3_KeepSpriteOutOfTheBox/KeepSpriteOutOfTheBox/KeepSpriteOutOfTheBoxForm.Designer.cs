﻿
namespace KeepSpriteOutOfTheBox
{
    partial class KeepSpriteOutOfTheBoxForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CanvasPictureBox = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.MouseCoordinatesCanvasLabel = new System.Windows.Forms.Label();
            this.GoofyEmojiPictureBox = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.MouseCoordinatesGoofyFaceLabel = new System.Windows.Forms.Label();
            this.MouseCoordinatesFormLabel = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.EdgeComboBox = new System.Windows.Forms.ComboBox();
            this.MoveSpriteButton = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.DistanceTextBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.GoofyFaceCoordinatesFormLabel = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.GoofyFaceCoordinatesCanvasLabel = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.ChangeBorderWidthButton = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.BorderWidthTextBox = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.CanvasPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GoofyEmojiPictureBox)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // CanvasPictureBox
            // 
            this.CanvasPictureBox.BackColor = System.Drawing.Color.White;
            this.CanvasPictureBox.Location = new System.Drawing.Point(20, 20);
            this.CanvasPictureBox.Name = "CanvasPictureBox";
            this.CanvasPictureBox.Size = new System.Drawing.Size(734, 452);
            this.CanvasPictureBox.TabIndex = 0;
            this.CanvasPictureBox.TabStop = false;
            this.CanvasPictureBox.Paint += new System.Windows.Forms.PaintEventHandler(this.CanvasPictureBox_Paint);
            this.CanvasPictureBox.MouseMove += new System.Windows.Forms.MouseEventHandler(this.CanvasPictureBox_MouseMove);
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(269, 8);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(194, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Mouse Co-ordinates Relative to Canvas";
            // 
            // MouseCoordinatesCanvasLabel
            // 
            this.MouseCoordinatesCanvasLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.MouseCoordinatesCanvasLabel.AutoSize = true;
            this.MouseCoordinatesCanvasLabel.Location = new System.Drawing.Point(352, 40);
            this.MouseCoordinatesCanvasLabel.Name = "MouseCoordinatesCanvasLabel";
            this.MouseCoordinatesCanvasLabel.Size = new System.Drawing.Size(27, 13);
            this.MouseCoordinatesCanvasLabel.TabIndex = 7;
            this.MouseCoordinatesCanvasLabel.Text = "N/A";
            // 
            // GoofyEmojiPictureBox
            // 
            this.GoofyEmojiPictureBox.BackColor = System.Drawing.Color.White;
            this.GoofyEmojiPictureBox.Image = global::KeepSpriteOutOfTheBox.Properties.Resources.funnyFaceTransparent;
            this.GoofyEmojiPictureBox.Location = new System.Drawing.Point(27, 208);
            this.GoofyEmojiPictureBox.Name = "GoofyEmojiPictureBox";
            this.GoofyEmojiPictureBox.Size = new System.Drawing.Size(50, 50);
            this.GoofyEmojiPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.GoofyEmojiPictureBox.TabIndex = 8;
            this.GoofyEmojiPictureBox.TabStop = false;
            this.GoofyEmojiPictureBox.MouseMove += new System.Windows.Forms.MouseEventHandler(this.GoofyEmojiPictureBox_MouseMove);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.Controls.Add(this.MouseCoordinatesGoofyFaceLabel, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.MouseCoordinatesFormLabel, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label5, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.label4, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.label3, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.MouseCoordinatesCanvasLabel, 1, 1);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(19, 571);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 45.34884F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 54.65116F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(734, 65);
            this.tableLayoutPanel1.TabIndex = 9;
            // 
            // MouseCoordinatesGoofyFaceLabel
            // 
            this.MouseCoordinatesGoofyFaceLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.MouseCoordinatesGoofyFaceLabel.AutoSize = true;
            this.MouseCoordinatesGoofyFaceLabel.Location = new System.Drawing.Point(597, 40);
            this.MouseCoordinatesGoofyFaceLabel.Name = "MouseCoordinatesGoofyFaceLabel";
            this.MouseCoordinatesGoofyFaceLabel.Size = new System.Drawing.Size(27, 13);
            this.MouseCoordinatesGoofyFaceLabel.TabIndex = 11;
            this.MouseCoordinatesGoofyFaceLabel.Text = "N/A";
            // 
            // MouseCoordinatesFormLabel
            // 
            this.MouseCoordinatesFormLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.MouseCoordinatesFormLabel.AutoSize = true;
            this.MouseCoordinatesFormLabel.Location = new System.Drawing.Point(108, 40);
            this.MouseCoordinatesFormLabel.Name = "MouseCoordinatesFormLabel";
            this.MouseCoordinatesFormLabel.Size = new System.Drawing.Size(27, 13);
            this.MouseCoordinatesFormLabel.TabIndex = 10;
            this.MouseCoordinatesFormLabel.Text = "N/A";
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(504, 8);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(213, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Mouse Co-ordinates Relative to Goofy Face";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(31, 8);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(181, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Mouse Co-ordinates Relative to Form";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.EdgeComboBox);
            this.groupBox1.Controls.Add(this.MoveSpriteButton);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.DistanceTextBox);
            this.groupBox1.Location = new System.Drawing.Point(19, 492);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(346, 73);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Move the Sprite";
            // 
            // EdgeComboBox
            // 
            this.EdgeComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.EdgeComboBox.FormattingEnabled = true;
            this.EdgeComboBox.Items.AddRange(new object[] {
            "N",
            "NE",
            "E",
            "SE",
            "S",
            "SW",
            "W",
            "NW"});
            this.EdgeComboBox.Location = new System.Drawing.Point(119, 41);
            this.EdgeComboBox.Name = "EdgeComboBox";
            this.EdgeComboBox.Size = new System.Drawing.Size(92, 21);
            this.EdgeComboBox.TabIndex = 20;
            // 
            // MoveSpriteButton
            // 
            this.MoveSpriteButton.Location = new System.Drawing.Point(218, 39);
            this.MoveSpriteButton.Name = "MoveSpriteButton";
            this.MoveSpriteButton.Size = new System.Drawing.Size(122, 23);
            this.MoveSpriteButton.TabIndex = 9;
            this.MoveSpriteButton.Text = "Move Sprite";
            this.MoveSpriteButton.UseVisualStyleBackColor = true;
            this.MoveSpriteButton.Click += new System.EventHandler(this.MoveSpriteButton_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(117, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(32, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Edge";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Distance (Pixels)";
            // 
            // DistanceTextBox
            // 
            this.DistanceTextBox.Location = new System.Drawing.Point(10, 42);
            this.DistanceTextBox.Name = "DistanceTextBox";
            this.DistanceTextBox.Size = new System.Drawing.Size(100, 20);
            this.DistanceTextBox.TabIndex = 5;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(366, 5);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(15, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "N";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(753, 8);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(22, 13);
            this.label7.TabIndex = 12;
            this.label7.Text = "NE";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(754, 225);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(14, 13);
            this.label8.TabIndex = 13;
            this.label8.Text = "E";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(366, 476);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(14, 13);
            this.label9.TabIndex = 14;
            this.label9.Text = "S";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(752, 471);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(21, 13);
            this.label10.TabIndex = 15;
            this.label10.Text = "SE";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(2, 473);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(25, 13);
            this.label11.TabIndex = 16;
            this.label11.Text = "SW";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(2, 225);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(18, 13);
            this.label12.TabIndex = 17;
            this.label12.Text = "W";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(3, 6);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(26, 13);
            this.label13.TabIndex = 18;
            this.label13.Text = "NW";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 3;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel2.Controls.Add(this.GoofyFaceCoordinatesFormLabel, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.label20, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.label18, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.GoofyFaceCoordinatesCanvasLabel, 1, 1);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(19, 646);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 45.34884F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 54.65116F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(734, 65);
            this.tableLayoutPanel2.TabIndex = 19;
            // 
            // GoofyFaceCoordinatesFormLabel
            // 
            this.GoofyFaceCoordinatesFormLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.GoofyFaceCoordinatesFormLabel.AutoSize = true;
            this.GoofyFaceCoordinatesFormLabel.Location = new System.Drawing.Point(108, 40);
            this.GoofyFaceCoordinatesFormLabel.Name = "GoofyFaceCoordinatesFormLabel";
            this.GoofyFaceCoordinatesFormLabel.Size = new System.Drawing.Size(27, 13);
            this.GoofyFaceCoordinatesFormLabel.TabIndex = 10;
            this.GoofyFaceCoordinatesFormLabel.Text = "N/A";
            // 
            // label20
            // 
            this.label20.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(20, 8);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(204, 13);
            this.label20.TabIndex = 8;
            this.label20.Text = "Goofy Face Co-ordinates Relative to Form";
            // 
            // label18
            // 
            this.label18.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(257, 8);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(217, 13);
            this.label18.TabIndex = 6;
            this.label18.Text = "Goofy Face Co-ordinates Relative to Canvas";
            // 
            // GoofyFaceCoordinatesCanvasLabel
            // 
            this.GoofyFaceCoordinatesCanvasLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.GoofyFaceCoordinatesCanvasLabel.AutoSize = true;
            this.GoofyFaceCoordinatesCanvasLabel.Location = new System.Drawing.Point(352, 40);
            this.GoofyFaceCoordinatesCanvasLabel.Name = "GoofyFaceCoordinatesCanvasLabel";
            this.GoofyFaceCoordinatesCanvasLabel.Size = new System.Drawing.Size(27, 13);
            this.GoofyFaceCoordinatesCanvasLabel.TabIndex = 7;
            this.GoofyFaceCoordinatesCanvasLabel.Text = "N/A";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.ChangeBorderWidthButton);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.BorderWidthTextBox);
            this.groupBox2.Location = new System.Drawing.Point(374, 492);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(380, 73);
            this.groupBox2.TabIndex = 20;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Change the Border Width";
            // 
            // ChangeBorderWidthButton
            // 
            this.ChangeBorderWidthButton.Location = new System.Drawing.Point(128, 39);
            this.ChangeBorderWidthButton.Name = "ChangeBorderWidthButton";
            this.ChangeBorderWidthButton.Size = new System.Drawing.Size(246, 23);
            this.ChangeBorderWidthButton.TabIndex = 9;
            this.ChangeBorderWidthButton.Text = "Change Border Width";
            this.ChangeBorderWidthButton.UseVisualStyleBackColor = true;
            this.ChangeBorderWidthButton.Click += new System.EventHandler(this.ChangeBorderWidthButton_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(7, 23);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(105, 13);
            this.label15.TabIndex = 7;
            this.label15.Text = "Border Width (Pixels)";
            // 
            // BorderWidthTextBox
            // 
            this.BorderWidthTextBox.Location = new System.Drawing.Point(10, 42);
            this.BorderWidthTextBox.Name = "BorderWidthTextBox";
            this.BorderWidthTextBox.Size = new System.Drawing.Size(112, 20);
            this.BorderWidthTextBox.TabIndex = 5;
            // 
            // KeepSpriteOutOfTheBoxForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(778, 718);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.tableLayoutPanel2);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.GoofyEmojiPictureBox);
            this.Controls.Add(this.CanvasPictureBox);
            this.Name = "KeepSpriteOutOfTheBoxForm";
            this.Text = "KeepSpriteOutOfTheBox - No Diagonal Movements";
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.KeepSpriteOutOfTheBoxForm_MouseMove);
            ((System.ComponentModel.ISupportInitialize)(this.CanvasPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GoofyEmojiPictureBox)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox CanvasPictureBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label MouseCoordinatesCanvasLabel;
        private System.Windows.Forms.PictureBox GoofyEmojiPictureBox;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label MouseCoordinatesGoofyFaceLabel;
        private System.Windows.Forms.Label MouseCoordinatesFormLabel;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button MoveSpriteButton;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox DistanceTextBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label GoofyFaceCoordinatesFormLabel;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label GoofyFaceCoordinatesCanvasLabel;
        private System.Windows.Forms.ComboBox EdgeComboBox;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button ChangeBorderWidthButton;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox BorderWidthTextBox;
    }
}

